<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Mild Steel Angles Manufacturers Suppliers Mumbai India</title>
	
	<meta name="description" content="Mild steel angles manufacturers, suppliers and exporters with MS, SS stainless products in Mumbai India to industrial company since 1992 ISO certified standards, long lasting features">

	<meta name="keywords" content="Mild Steel Angles">

    <!-- Bootstrap -->
	<link href="img/shortcut.png" rel="shortcut icon">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Rubik&display=swap" rel="stylesheet">
    <!-- Font Awsome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"  crossorigin="anonymous">

  </head>
  <body>



<div class="wtsp">
  <a href="https://api.whatsapp.com/send?phone=919869039420"><img src="img/wtsp.png" class="img-responsive"></a>
</div>

<div class="top-head">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="top-logo">
          <a href="https://www.fine-industries.com/"><img src="img/top-logo.svg" class="img-responsive"></a>
        </div>
      </div>
       <div class="col-md-6">
        <div class="top-cont">
          <span class="top-cont-email">
           <ul>
             <li><img src="img/email.svg"> </li>
             <li> <span>EMAIL US:</span><br class="breck"> <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="3e4d5f525b4d7e5857505b1357505a4b4d4a4c575b4d105d5153">[email&#160;protected]</a></li>
           </ul>
           </span>
           <span class="top-cont-email">
           <ul>
             <li><img src="img/smartphone.svg"> </li>
             <li> <span>CALL US:</span><br class="breck"> +022-23742662 </li>
           </ul>
           </span>
        </div>
      </div>
    </div>
  </div>
</div>


<header>
<nav id='cssmenu'>
<div class="logo"><a href="https://www.fine-industries.com/"><img src="img/top-logo.svg" class="img-responsive"> </a></div>
<div id="head-mobile"></div>
<div class="button"></div>
<ul>
<li class='active'><a href="https://www.fine-industries.com/">HOME</a></li>
 
<li><a href='#'>ABOUT US</a>
   <ul>
      <li><a href='about.php'>Company Information</a> </li>
      <li><a href='our-team.php'>Our Team</a> </li>
   </ul>
</li>
<li><a href='#'>PRODUCTS</a>
   <ul>
      <li><a href='ms-flange.php'>Flanges</a>
         <ul>
            <li><a href='carbon-steel-flanges.php'>CS Flanges</a></li>
            <li><a href='mild-steel-flanges.php'>MS Flanges</a></li>
            <li><a href='stainless-steel-flanges.php'>SS Flanges</a></li>
            <li><a href='forged-flanges.php'>Forged Flanges</a></li>
            <li><a href='weldneck.php'>Weldneck</a></li>
         </ul>
      </li>
      <li><a href='pipe-fitting.php'>Pipe Fitting</a>
		<ul>
            <li><a href='socket-weld-fittings.php'>Socket Weld Elbow</a></li>
            <li><a href='threaded-elbow-fittings.php'>Threaded Elbow</a></li>
            <li><a href='concentric-reducer.php'>Concentric Reducer</a></li>
            <li><a href='barrel-nipple-connector.php'>Barrel Nipple</a></li>
			<li><a href='hose-nipple-stainless-steel.php'>Hose Nipple</a></li>
            <li><a href='stainless-steel-connectors.php'>Stainless Steel Connectors</a></li>
         </ul>
	  </li>
      <li><a href='valve.php'>Valve</a> </li>
      <li><a href='profile-cutting.php'>Profile Cuttings</a> </li>
      <li><a href='#'>Plate</a>
         <ul>
            <li><a href='ms-plate.php'>MS Plate</a></li>
            <li><a href='ss-plate.php'>SS Plate</a></li>
         </ul>
      </li>
      <li><a href='#'>Pipe</a>
         <ul>
            <li><a href='pipe-erw.php'>ERW</a></li>
            <li><a href='pipe-seamless.php'>Seamless</a></li>
         </ul>
      </li>
      <li><a href='round-bar.php'>Round Bar</a> </li>
      <li><a href='fastners.php'>Fastner</a> </li>
      <li><a href='#'>Structural Steel</a>
         <ul>
            <li><a href='steel-angles.php'>Angle</a></li>
            <li><a href='steel-channel.php'>Channel</a></li>
            <li><a href='steel-beam.php'>Beam</a></li>
         </ul>
      </li>
   </ul>
</li>
<li><a href='gallery.php'>GALLERY</a></li>
<li><a href='certificates.php'>CERTIFICATES</a></li>
<li><a href='img/brochure.pdf'>CATALOGUE</a></li>
<li><a href='client.php'>CLIENTELE</a></li>
<li><a href='contact.php'>CONTACT US</a></li>
</ul>
</nav>
</header>
<!-- inner-banner -->
 <div class="inner-banner">
   <div class="container">
     <div class="row">
       <div class="col-md-12">
         <div class="inner-banner-dtl">
           <h1>Mild Steel Angles</h1>
           <h4>100% Satisfaction</h4>
         </div>
       </div>
     </div>
   </div>
 </div>

<div class="inner-head">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="inner-head-dtl">
          <span><a href="https://www.fine-industries.com/"><i class="fa fa-home"></i></a></span>
          <span> <i class="fa fa-angle-right"></i> </span>
          <span>Mild Steel Angles</span>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- inner-banner-end -->
<div class="about">
  <div class="container">
  <div class="row">
    <div class="col-md-8">
      <div class="about-dtl">
        <h2>Mild Steel Angles</h2>
        <p>Fine Industrial corporation suppliers wide range of <strong>Mild Steel Angles</strong>, which is used in truck-trailer, EOT cranes and gantry, escalator and elevator, ship building, factory sheds, bus body, communication and transmission towers, conveyor, boilers, agricultural department, and construction of bridge, scaffolding and many more fabrication and engineering industries. We are manufacturers and exporters of stainless steel angles in Mumbai to worldwide company. We have a trusted company in India, our industry is reliable suppliers of mild steel angle with assured safety features and ISO standards.</p> 
        <p>Material available in 25mm x 25mm x 3mm To 130mm x 130mm x 12mm</p>
        <p>Grades : En8 / En8D / En9  / En16</p>
      </div>
    </div>
    <div class=" col-md-4">
      <div class="inner-prod-menu">
         <img src="img/steel-angles.jpg" class="img-responsive" alt="Steel Angles">  
      </div>
    </div>
    </div>
  </div>
</div>

<br>
<br>



<div class="hm-call-main">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="hm-call">
          <h3>CALL US AT <span>( +91 98334 03387 )</span> OR <a href="contact.php">( Request a Quote )</a> TODAY</h3>
        </div>
      </div>
    </div>
  </div>
</div>
<!--------------->
<div class="hm-footer-main">
  <div class="container">
    <div class="row foot-line">
      <div class="col-md-12 col-sm-12">
        <div class="foot-tit">Contact Details</div>
      </div>
      <div class="col-md-3 col-sm-3">
        <div class="fot-tit-main">
          <h4>Nature of Business Manufacturer</h4>
        </div>
      </div>
      <div class="col-md-3 col-sm-3">
        <div class="fot-tit-main">
          <h4>Nature of Business Exporter And Supplier</h4>
        </div>
      </div>
      <div class="col-md-3 col-sm-3">
        <div class="fot-tit-main">
          <h4>Year of Establishment Act, 1992</h4>
        </div>
      </div>
      <div class="col-md-3 col-sm-3">
        <div class="fot-tit-main">
          <h4>We are an ISO 9001 : 2015 certified company</h4>
        </div>
      </div>
    </div>
  </div>
  <div class="container-fluid">
    <div class="row foot-gap">
      
      <div class="col-md-3 col-sm-3 col-xs-6">
        <div class="foot-gap">
          <div class="foot-head">
            <h4>Products</h4>
          </div>
          <div class="foot-para">
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="carbon-steel-flanges.php">Flanges</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="pipe-fitting.php">Pipe Fitting</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="valve.php">Valve</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="profile-cutting.php">Profile Cuttings</a></p>
              <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="ms-plate.php">Plate</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="pipe-erw.php">Pipe</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="round-bar.php">Round Bar</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="fastners.php">Fastner</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="steel-angles.php">Structural Steel</a></p>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-3 col-xs-6">
        <div class="foot-gap">
          <div class="foot-head">
            <h4>Quick Link</h4>
          </div>
          <div class="foot-para">
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="https://www.fine-industries.com/">Home</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="about.php">About Us</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="gallery.php">Gallery</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="certificates.php">Certificates</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="img/brochure.pdf">Catalogue</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="client.php">Clientele</a></p>
            <p><i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="contact.php">Contact Us</a></p>
          </div>
        </div>

      </div>


      <div class="col-md-3 col-sm-3" >
          <br  style="clear: both;">
        <div class="foot-gap">
          <div class="foot-head">
            <h4>Office Address :-</h4>
          </div>
          <div class="foot-hed">
            <div class="foot-icon">
              <i class="fa fa-home" aria-hidden="true"></i>
            </div>
            <div class="foot-par">
              <p>Plot No-100/101, Reti Bunder Road, Near Manikant Godown & Dhakka No-4, Reay Road, Darukhana, Mumbai-400010.</p>
            </div>
          </div>
          <div class="foot-hed">
            <div class="foot-icon">
              <i class="fa fa-envelope" aria-hidden="true"></i>
            </div>
            <div class="foot-par">
              <p><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="d7a4b6bbb2a497b1beb9b2fabeb9b3a2a4a3a5beb2a4f9b4b8ba">[email&#160;protected]</a></p>
            </div>
          </div>
          <div class="foot-hed">
            <div class="foot-icon">
              <i class="fa fa-phone"></i>
            </div>
            <div class="foot-par">
              <p>+91 9833403387 / 9869717920</p>
            </div>
          </div>
        </div>
      </div>
       
      <div class="col-md-3 col-sm-3">
        <div class="foot-social">
          <ul>
            <li class="s1"><a href="https://www.facebook.com/Fine-Industrial-Corporation-112673800265865/?modal=admin_todo_tour"><i class="fa  fa-facebook-f"></i></a></li>
            <li class="s2"><a href="https://twitter.com/industries_fine"><i class="fa  fa-twitter"></i></a></li>
            <li class="s3"><a href="https://www.youtube.com/channel/UCp6AclWVD29O1LGNvQ9aZyg?view_as=subscriber"><i class="fa  fa-youtube"></i></a></li>
            <li class="s4"><a href="#"><i class="fa  fa-skype"></i></a></li>
          </ul>
          <h5>Copyright@2020 www.fine-industries.com <br /> All Rights Reserved.</h5>
          <img src="img/make-in-india.png" class="img-responsive"/>
        </div>
      </div>
    </div>
  </div>
</div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/menu.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>

  </body>
</html>